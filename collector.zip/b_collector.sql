-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2020 at 07:46 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otdms`
--

-- --------------------------------------------------------

--
-- Table structure for table `b_collector`
--

CREATE TABLE `b_collector` (
  `id` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `uniqueID` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `department` varchar(50) NOT NULL,
  `mobileno` int(20) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `b_collector`
--

INSERT INTO `b_collector` (`id`, `Name`, `uniqueID`, `Email`, `gender`, `department`, `mobileno`, `password`) VALUES
(2, 'Godfred Adu-sarfo', 'OPD 22-44', 'gadusarfo99@gmail.com', 'Male', 'OPD', 547950211, '9dc59f9065e8b288e3b7a5705');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `b_collector`
--
ALTER TABLE `b_collector`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `b_collector`
--
ALTER TABLE `b_collector`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
