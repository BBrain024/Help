<div class="logo">
 Copyright &copy; BloodBank & Organ Transplanting Management System 2020
  </div>
<div class="menu-area">
<li ><a href="homepage.php">Ok</a> </li>
</div>