  
  
  <footer class="py-5 bg-inverse">

        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; BloodBank & Organ Transplanting System 2020</p>
            	<ul class="navbar-nav ml-auto">
  	 <li class="nav-item">
                        <a class="nav-link" href="page.php?type=aboutus">About</a>
                    </li>

     <li class="nav-item">
                        <a class="nav-link" href="logout.php">Log out</a>
                    </li>
                    
                </ul>
 
               
        </div>

        <!-- /.container -->
    </footer>