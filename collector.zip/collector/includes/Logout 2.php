<?php
header("location:homepage2.php");
?>