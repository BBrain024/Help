    <nav class="navbar fixed-top navbar-toggleable-md navbar-inverse bg-inverse">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="container">
            <a class="navbar-brand" href="index.php">Blood Bank & Organ Transplanting System</a>
            <div class="collapse navbar-collapse" id="navbarExample">
                <ul class="navbar-nav ml-auto">
                   
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?type=donor">Why Donate</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="become-donar.php">Blood Donation</a>
                    </li>
                      <li class="nav-item">
                        <a class="nav-link" href="become-donar2.php">Organ Donation</a>
                    </li>
                 
                     <li class="nav-item">
                        <a class="nav-link" href="search-donor.php">Search Blood</a>
                    </li>
                    
                     <li class="nav-item">
                        <a class="nav-link" href='search-donor 2.php'>Search Organ</a>
                    </li>
                    
                 
                 
                </ul>
            </div>
        </div>
    </nav>
